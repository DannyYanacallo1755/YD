public class Tematica {
    //Atributos privvados para almacenar el nombre y el tipo
    private String nombre;
    private String tipo;

    public Tematica(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo(String tipo) {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
        public class Main {
            public static void main(String[] args) {
                Tematica tematica1 = new Tematica("El quijote de la mancha", "Literatuta");
                Tematica tematica2 = new Tematica("La odisea", "Literatuta");
                Tematica tematica3 = new Tematica("Harry Potter", "Literatuta");
                Tematica tematica4 = new Tematica("The witcher", "Literatuta");
                Tematica tematica5 = new Tematica("Caperucita y el lobo", "Literatuta");
                Tematica tematica01 = new Tematica("Ori and the blind forest", "Videojuego");
                Tematica tematica02 = new Tematica("Crisis Core", "Videojuego");
                Tematica tematica03 = new Tematica("Mainecraft", "Videojuego");
                Tematica tematica04 = new Tematica("Doom", "Videojuego");
                Tematica tematica05 = new Tematica(" The forest", "Videojuego");


                System.out.println(tematica1.getNombre()+"-"+tematica1.getTipo());
                System.out.println(tematica2.getNombre()+"-"+ tematica2.getTipo());
                System.out.println(tematica3.getNombre()+"-"+tematica3.getTipo());
                System.out.println(tematica4.getNombre()+"-"+tematica4.getTipo());
                System.out.println(tematica5.getNombre()+"-"+tematica5.getTipo());
                System.out.println(tematica01.getNombre()+"-"+tematica01.getTipo());
                System.out.println(tematica02.getNombre()+"-"+tematica02.getTipo());
                System.out.println(tematica03.getNombre()+"-"+tematica03.getTipo());
                System.out.println(tematica04.getNombre()+"-"+tematica04.getTipo());
                System.out.println(tematica05.getNombre()+"-"+tematica05.getTipo());

                tematica1.setTipo("VideoJuegos");
                tematica2.setNombre("Mario Bros");
                tematica01.setTipo("Crepusculo");

                System.out.println(tematica1.getNombre()+"-"+tematica1.getTipo());
                System.out.println(tematica2.getNombre()+"-"+tematica2.getTipo());
                System.out.println(tematica3.getNombre()+"-"+tematica3.getTipo());
                System.out.println(tematica4.getNombre()+"-"+tematica4.getTipo());
                System.out.println(tematica01.getNombre()+"-"+tematica01.getTipo());

        }

        }


